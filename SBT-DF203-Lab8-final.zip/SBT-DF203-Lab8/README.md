# SBT-DF203-Lab8 — DNS Spoofing Forensics

Forensic analysis lab: capturing and analyzing DNS spoofing indicators correlated with ARP evidence, in an isolated host-only network.

## ⚠️ Scope Note

**This repo covers the forensic analysis workflow (Parts A, D, E, F): baseline capture, evidence analysis, comparison, and cleanup.**

Parts B and C (running `arp.py` / `dns_spoof.py` against a victim VM) require live instructor supervision per the lab manual and are **not automated or scripted here**. If your course has no supervisor available, raise that with your program before running interception tooling — this repo assumes that step happens separately, under proper authorization, and you drop the resulting `.pcapng` file into `evidence/` afterward.

## Folder Structure

```
SBT-DF203-Lab8/
├── evidence/       # Original, untouched pcap captures (never edit these)
├── working/        # Working copies for analysis
├── exported/       # Exported objects/artifacts from pcaps
├── reports/        # Command output (tsv/txt), hashes, analysis tables
├── screenshots/    # Numbered screenshots per the checklist
├── scripts/        # Instructor-provided scripts (reviewed, not run here)
└── report/         # Final report (Markdown -> PDF)
```

## Step-by-Step

1. **Setup** — see `docs/01-setup.md`
2. **Part A: Baseline capture** — see `docs/02-baseline.md`
3. **Part B/C: Controlled simulation** — done live with instructor; drop pcap into `evidence/`
4. **Part D/E: Analysis & comparison** — see `docs/03-analysis.md`
5. **Part F: Cleanup** — see `docs/04-cleanup.md`
6. **Report** — fill `report/REPORT_TEMPLATE.md`, export to PDF, zip per submission requirements

## Chain of Custody

Every evidence file gets a SHA-256 hash recorded in `reports/` **at creation** and **before analysis**. See `reports/chain_of_custody.md`.
