# SBT-DF203-Lab8 Report — [Your Full Name] — [Reg No]

## 1. Executive Summary and Authorization
- Purpose of the lab, scope of authorization, isolated network used.

## 2. Lab Network Diagram
- Diagram of analyst VM, victim VM, gateway, all on host-only network. (Insert image.)

## 3. Baseline Evidence and Hashes
- Identity table (from chain_of_custody.md)
- `dns_baseline.pcapng` SHA-256
- Legitimate DNS answer: responder IP/MAC, TTL, response time

## 4. Controlled Simulation Method
- Summary of instructor-supervised session: scripts used, target/domain settings reviewed, duration, approval confirmation.

## 5. DNS Anomaly Timeline
- Sequence of events from `dns_all_fields.tsv`: frame numbers, timestamps, competing answers.

## 6. ARP Correlation
- Findings from `arp_claims_during_spoof.tsv`: which IP was claimed by which MAC, and when.

## 7. Victim Connection Correlation
- Findings from `post_dns_connections.tsv`: victim's HTTP connection following the forged answer.

## 8. Comparison Table
(Insert filled table from `reports/comparison_table.md`)

## 9. Alternative Explanations and Confidence Level
- DNS caching / split-horizon / round-robin ruled in or out.
- Overall confidence level in the "spoofing" finding and why.

## 10. Cleanup and Defensive Recommendations
- Confirm cleanup steps completed (link `process_cleanup_check.txt`).
- Recommendations: DNSSEC, Dynamic ARP Inspection, DHCP snooping, HTTPS validation, correlated monitoring.

## 11. Appendix
- Full command outputs, additional screenshots, raw TSV excerpts.
