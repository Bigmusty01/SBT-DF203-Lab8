Evidence pcaps are excluded from git (see .gitignore) — keep them locally or use Git LFS. Only hashes in reports/ are committed.
