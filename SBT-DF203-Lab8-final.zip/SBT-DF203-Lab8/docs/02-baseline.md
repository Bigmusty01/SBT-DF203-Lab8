# Step 2 — Part A: Document the Baseline

Goal: capture **normal** DNS/ARP behavior before any spoofing occurs, so you have something legitimate to compare against later.

## 2.1 Record identities

Fill this in `reports/chain_of_custody.md` or a scratch note before capturing:

| Role | IP | MAC |
|---|---|---|
| Victim VM | | |
| Analyst VM | | |
| Gateway | | |
| DNS resolver | | |

## 2.2 Capture baseline traffic

On the analyst VM (replace `IFACE` and `VICTIM_IP`):

```bash
sudo tshark -i IFACE -f 'host VICTIM_IP and (arp or port 53 or tcp port 80)' \
  -a duration:30 -w evidence/dns_baseline.pcapng &
sleep 3
```

On the **victim**, resolve the instructor-assigned training name using the legitimate resolver:

```bash
dig portal.icdfa.test A
```

Then:

```bash
wait
sha256sum evidence/dns_baseline.pcapng | tee reports/dns_baseline_sha256.txt
```

## 2.3 What to record from this capture

Open `evidence/dns_baseline.pcapng` in Wireshark (or use tshark filters) and note:
- Legitimate responder IP/MAC
- TTL of the DNS answer
- Query → response time
- The resolved A record

This becomes the "Baseline" column in your Part E comparison table.

## Screenshot checklist
- [ ] Identity table filled in
- [ ] Baseline capture hash
- [ ] Legitimate DNS response visible in Wireshark

## Next
Parts B/C (the controlled spoofing simulation) require live instructor supervision — not covered here. Once you have `evidence/dns_spoof_controlled.pcapng` from that supervised session, continue to → `docs/03-analysis.md`
