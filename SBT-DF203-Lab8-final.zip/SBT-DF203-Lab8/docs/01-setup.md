# Step 1 — Environment Setup

Run on your **analyst VM** (Kali or similar), inside a host-only/NAT virtual network — never on a production or shared network.

## 1.1 Create folder structure (if not already cloned from this repo)

```bash
mkdir -p ~/SBT-DF203-Lab8/{evidence,working,exported,reports,screenshots,scripts}
cd ~/SBT-DF203-Lab8
pwd
find . -maxdepth 1 -type d -print
```

## 1.2 Install tools

```bash
sudo apt update
sudo apt install -y apache2 tshark wireshark python3-scapy python3-pip build-essential python3-dev libnetfilter-queue-dev
sudo systemctl enable --now apache2
```

## 1.3 Deploy the harmless training warning page

```bash
printf '<!DOCTYPE html>\n<html><body style="font-family:Arial"><h1>ICDFA DNS Spoofing Training Page</h1><p>This is an authorized simulation. Do not enter credentials.</p><p>Analyst: YOUR NAME</p></body></html>\n' | sudo tee /var/www/html/index.html
sha256sum /var/www/html/index.html | tee reports/training_page_sha256.txt
```

Confirm the page has **no forms, no credential fields** — only the warning text.

## 1.4 Record network baseline

```bash
ip -br address | tee reports/interfaces.txt
ip route | tee reports/routes.txt
ip neigh show | tee reports/arp_before.txt
```

## Screenshot checklist for this step
- [ ] Training page rendered in a browser + its SHA-256 hash
- [ ] `interfaces.txt` output
- [ ] `routes.txt` output
- [ ] `arp_before.txt` output

## Next
→ `docs/02-baseline.md`
