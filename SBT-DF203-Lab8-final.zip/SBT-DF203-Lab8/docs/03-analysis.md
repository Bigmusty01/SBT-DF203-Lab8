# Step 3 — Parts D & E: Detection and Comparison

Assumes `evidence/dns_spoof_controlled.pcapng` already exists from a supervised session.

## 3.1 Hash it immediately

```bash
PCAP=evidence/dns_spoof_controlled.pcapng
sha256sum "$PCAP" | tee reports/dns_spoof_capture_sha256.txt
```

## 3.2 Extract DNS fields

```bash
tshark -r "$PCAP" -Y 'dns' -T fields \
  -e frame.number -e frame.time_epoch -e eth.src -e eth.dst -e ip.src -e udp.srcport \
  -e ip.dst -e udp.dstport -e dns.id -e dns.flags.response -e dns.qry.name -e dns.qry.type \
  -e dns.flags.rcode -e dns.a -e dns.resp.ttl \
  | tee reports/dns_all_fields.tsv
```

**What you're looking for:** two responses to the same `dns.id` with different `dns.a` (answer IP) values, or a response whose `eth.src` MAC doesn't match the legitimate resolver's known MAC.

## 3.3 Extract ARP claims

```bash
tshark -r "$PCAP" -Y 'arp.opcode==2' -T fields \
  -e frame.number -e frame.time_epoch -e arp.src.proto_ipv4 -e arp.src.hw_mac \
  -e arp.dst.proto_ipv4 -e arp.dst.hw_mac \
  | tee reports/arp_claims_during_spoof.tsv
```

**What you're looking for:** the gateway or victim IP mapped to an unexpected MAC.

## 3.4 Extract the follow-on HTTP connection

```bash
tshark -r "$PCAP" -Y 'http.request || tcp.flags.syn==1' -T fields \
  -e frame.number -e frame.time_epoch -e ip.src -e tcp.srcport -e ip.dst -e tcp.dstport -e http.host -e http.request.uri \
  | tee reports/post_dns_connections.tsv
```

**What you're looking for:** the victim connecting to the forged (analyst) IP right after the spoofed answer.

## 3.5 Fill in the comparison table

Copy this into `reports/comparison_table.md` and fill using baseline vs. controlled-capture data:

| Indicator | Baseline | Controlled Spoof | Assessment |
|---|---|---|---|
| DNS responder IP | | | |
| DNS responder MAC | | | |
| Transaction ID match | | | |
| Answer IP | | | |
| TTL | | | |
| Response time | | | |
| Competing answers | | | |
| Gateway ARP mapping | | | |
| Subsequent HTTP destination | | | |

## 3.6 Consider alternative explanations

Before concluding "spoofing," rule out: DNS caching, split-horizon DNS, multiple legitimate answers (round-robin/CDN), and stale ARP entries. Note your reasoning in the report.

## Screenshot checklist
- [ ] Capture hash
- [ ] DNS query + conflicting/forged response rows
- [ ] ARP claims during event
- [ ] Victim HTTP connection to replacement IP
- [ ] Filled comparison table

## Next
→ `docs/04-cleanup.md`
