# Step 4 — Part F: Cleanup and Verification

Run immediately after evidence is captured — don't leave the simulation running.

```bash
# Stop any simulation scripts
sudo pkill -f 'arp.py' 2>/dev/null || true
sudo pkill -f 'dns_spoof.py' 2>/dev/null || true

# Restore forwarding to its recorded pre-lab value (example disables it)
sudo sysctl -w net.ipv4.ip_forward=0

# Confirm/restore iptables to the saved snapshot from reports/iptables_before.rules
sudo iptables -L -n -v --line-numbers | tee reports/iptables_after_cleanup.txt

# Flush learned ARP entries on the isolated VMs
sudo ip neigh flush all
ip neigh show | tee reports/arp_after_cleanup.txt

# Confirm nothing is still running
ps aux | grep -E '[a]rp.py|[d]ns_spoof.py' | tee reports/process_cleanup_check.txt
```

## Verification checklist
- [ ] `arp.py` / `dns_spoof.py` processes confirmed stopped
- [ ] `ip_forward` restored to original value
- [ ] iptables rules match pre-lab snapshot
- [ ] ARP table cleared and reconnected cleanly
- [ ] `process_cleanup_check.txt` shows no matches

## Next
Write up `report/REPORT_TEMPLATE.md`, export to PDF, then see the main README for GitHub submission steps.
