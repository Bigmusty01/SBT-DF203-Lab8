# Chain of Custody Worksheet

| Field | Entry |
|---|---|
| Case/lab identifier | SBT-DF203-Lab8-YourFullName |
| Trainee name | |
| Date and time started | |
| Evidence file name(s) | |
| Source or generation method | |
| Original SHA-256 | |
| Working-copy SHA-256 | |
| Analysis workstation/VM | |
| Notes on any changes | |

## Identity Table (Part A)

| Role | IP | MAC |
|---|---|---|
| Victim VM | | |
| Analyst VM | | |
| Gateway | | |
| DNS resolver | | |
